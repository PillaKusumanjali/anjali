/*
TO DO
Customize email icon
Build page for Learn More
*/